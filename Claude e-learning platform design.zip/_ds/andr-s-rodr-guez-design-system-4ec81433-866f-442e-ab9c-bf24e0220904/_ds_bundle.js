/* @ds-bundle: {"format":3,"namespace":"AndrSRodrGuezDesignSystem_4ec814","components":[{"name":"AvailabilityBadge","sourcePath":"components/core/AvailabilityBadge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"SectionHeading","sourcePath":"components/core/SectionHeading.jsx"},{"name":"Accent","sourcePath":"components/core/SectionHeading.jsx"},{"name":"ServiceCard","sourcePath":"components/core/ServiceCard.jsx"},{"name":"Stat","sourcePath":"components/core/Stat.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"}],"sourceHashes":{"components/core/AvailabilityBadge.jsx":"9f5d20e03bd8","components/core/Button.jsx":"a8262d739064","components/core/Card.jsx":"f75626c11f26","components/core/Eyebrow.jsx":"77e40368d1f5","components/core/IconButton.jsx":"828d08293121","components/core/Input.jsx":"dd08900ebfa0","components/core/SectionHeading.jsx":"6ccdfb9a15e4","components/core/ServiceCard.jsx":"9a3151b6d098","components/core/Stat.jsx":"aeb249a73aae","components/core/Tag.jsx":"c241773a7718","ui_kits/portfolio/Contacto.jsx":"8340e4c6dfa3","ui_kits/portfolio/Footer.jsx":"d8ff980c64c2","ui_kits/portfolio/Hero.jsx":"f25c60aeec18","ui_kits/portfolio/Metodologia.jsx":"c1e304fd8417","ui_kits/portfolio/Navbar.jsx":"b63d48e0118e","ui_kits/portfolio/Servicios.jsx":"cb668b160097","ui_kits/portfolio/Trayectoria.jsx":"3d028a3e1990","ui_kits/portfolio/app.jsx":"c3ee7a0a93f3","ui_kits/portfolio/icons.js":"59542f76aa16"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AndrSRodrGuezDesignSystem_4ec814 = window.AndrSRodrGuezDesignSystem_4ec814 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/AvailabilityBadge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AvailabilityBadge — the brand's "responde < 24h" capsule: a small cream
 * dot + caption, framed as a hairline pill. Signals responsiveness.
 */
function AvailabilityBadge({
  children = 'responde < 24h',
  dotColor,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: "ar-availability",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      padding: '6px 12px',
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--border-default)',
      background: 'color-mix(in srgb, var(--surface-default) 60%, transparent)',
      fontSize: 'var(--text-caption)',
      color: 'var(--text-body)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 8,
      height: 8,
      borderRadius: 999,
      background: dotColor || 'var(--ar-cream)',
      flex: 'none'
    }
  }), children);
}
Object.assign(__ds_scope, { AvailabilityBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/AvailabilityBadge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — the brand's pill control.
 *
 * Variants:
 *   primary  → inverted chip (vellum on dark / ink on light). The default CTA.
 *   ghost    → transparent with a steel hairline border.
 *   link     → italic Instrument-Serif text link with an accent underline.
 * Sizes: sm · md · lg. Set `arrow` to append the brand's → glyph.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  arrow = false,
  icon = null,
  disabled = false,
  href,
  type = 'button',
  onClick,
  style,
  ...rest
}) {
  const pads = {
    sm: '8px 18px',
    md: '14px 26px',
    lg: '16px 30px'
  };
  const fontSizes = {
    sm: 13,
    md: 14,
    lg: 14
  };
  const base = {
    fontFamily: 'var(--font-sans)',
    fontSize: fontSizes[size],
    fontWeight: 'var(--fw-semibold)',
    lineHeight: 1,
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.45 : 1,
    transition: 'background .18s ease, color .18s ease, border-color .18s ease, transform .12s ease',
    whiteSpace: 'nowrap',
    textDecoration: 'none',
    border: '1px solid transparent',
    borderRadius: 'var(--radius-pill)',
    padding: pads[size],
    boxSizing: 'border-box'
  };
  const variants = {
    primary: {
      background: 'var(--control-bg)',
      color: 'var(--control-fg)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-headline)',
      borderColor: 'var(--border-strong)',
      fontWeight: 'var(--fw-medium)'
    },
    link: {
      background: 'transparent',
      color: 'var(--text-accent)',
      borderRadius: 0,
      padding: size === 'sm' ? '4px 0' : '8px 0',
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontSize: size === 'lg' ? 19 : 18,
      borderBottom: '1px solid var(--text-accent)',
      gap: 8
    }
  };
  const cls = `ar-btn ar-btn--${variant}${disabled ? ' is-disabled' : ''}`;
  const Tag = href && !disabled ? 'a' : 'button';
  const tagProps = href && !disabled ? {
    href
  } : {
    type,
    disabled
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls,
    onClick: disabled ? undefined : onClick,
    style: {
      ...base,
      ...variants[variant],
      ...style
    }
  }, tagProps, rest), icon, children, arrow && /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M5 12h14M13 6l6 6-6 6"
  })));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — generic surface container. `tone` picks the surface level; `accent`
 * draws an azure-glow border for highlighted/featured cards.
 */
function Card({
  children,
  tone = 'raised',
  accent = false,
  padding = 28,
  style,
  ...rest
}) {
  const surfaces = {
    default: 'var(--surface-default)',
    raised: 'var(--surface-raised)'
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    className: "ar-card",
    style: {
      background: surfaces[tone] || surfaces.raised,
      border: accent ? '1px solid rgba(94,160,255,0.3)' : '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: accent ? 'var(--shadow-glow)' : 'var(--shadow-soft)',
      padding,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Eyebrow — the brand's recurring section opener: a short accent rule
 * followed by an uppercase mono label. Often prefixed with a section mark
 * like "§02".
 */
function Eyebrow({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: "ar-eyebrow",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-mono)',
      letterSpacing: 'var(--tracking-mono)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 28,
      height: 1,
      background: 'var(--accent)',
      flex: 'none'
    }
  }), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconButton — round, hairline-bordered icon control. Used for nav toggles,
 * social links and the hero's secondary actions. Pass an SVG/icon node as
 * children. `filled` swaps to the inverted control chip.
 */
function IconButton({
  children,
  filled = false,
  size = 'md',
  href,
  label,
  onClick,
  style,
  ...rest
}) {
  const dims = {
    sm: 34,
    md: 44,
    lg: 48
  };
  const d = dims[size];
  const base = {
    width: d,
    height: d,
    borderRadius: 'var(--radius-pill)',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    transition: 'background .18s ease, border-color .18s ease, color .18s ease',
    flex: 'none',
    textDecoration: 'none',
    background: filled ? 'var(--control-bg)' : 'transparent',
    color: filled ? 'var(--control-fg)' : 'var(--text-headline)',
    border: filled ? '1px solid transparent' : '1px solid var(--border-strong)',
    ...style
  };
  const Tag = href ? 'a' : 'button';
  const tagProps = href ? {
    href
  } : {
    type: 'button'
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: "ar-icon-btn",
    "aria-label": label,
    onClick: onClick,
    style: base
  }, tagProps, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — editorial field. Italic serif label sits above a baseline-rule
 * input that brightens to the accent on focus. `as="textarea"` for multiline.
 */
function Input({
  label,
  value,
  defaultValue,
  placeholder,
  onChange,
  as = 'input',
  rows = 4,
  id,
  style,
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const fieldId = id || React.useId();
  const fieldStyle = {
    display: 'block',
    width: '100%',
    marginTop: 6,
    padding: '12px 0',
    background: 'transparent',
    border: 'none',
    borderBottom: `1px solid ${focused ? 'var(--accent)' : 'var(--border-strong)'}`,
    outline: 'none',
    fontFamily: 'var(--font-sans)',
    fontSize: 17,
    color: 'var(--text-headline)',
    boxSizing: 'border-box',
    transition: 'border-color .18s ease',
    resize: as === 'textarea' ? 'vertical' : undefined,
    lineHeight: as === 'textarea' ? 1.55 : undefined
  };
  const Field = as;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: 'block',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontSize: 14,
      color: focused ? 'var(--text-accent)' : 'var(--text-muted)',
      transition: 'color .18s ease'
    }
  }, label), /*#__PURE__*/React.createElement(Field, _extends({
    id: fieldId,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    onChange: onChange,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    rows: as === 'textarea' ? rows : undefined,
    style: fieldStyle
  }, rest)));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SectionHeading — the brand's section header lockup: eyebrow, a big
 * Bricolage display headline (with optional italic-serif accent word), and
 * an optional serif italic deck. Drives the rhythm of every page section.
 */
function SectionHeading({
  eyebrow,
  children,
  deck,
  size = 'lg',
  align = 'left',
  style,
  ...rest
}) {
  const sizes = {
    md: 'var(--text-display-md)',
    lg: 'var(--text-display-lg)',
    xl: 'var(--text-display-xl)'
  };
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      textAlign: align,
      ...style
    }
  }, rest), eyebrow && /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: eyebrow ? '20px 0 0' : 0,
      fontFamily: 'var(--font-display)',
      fontSize: sizes[size],
      fontWeight: 'var(--fw-extrabold)',
      letterSpacing: 'var(--tracking-display)',
      lineHeight: 'var(--leading-display)',
      color: 'var(--text-headline)'
    }
  }, children), deck && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '20px 0 0',
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontSize: 'var(--text-subtitle)',
      color: 'var(--text-warm)',
      lineHeight: 'var(--leading-snug)'
    }
  }, deck));
}

/**
 * Accent — wraps a word in the italic-serif accent treatment used inside
 * display headlines. <h2>De idea a producción en <Accent>cuatro</Accent> fases.</h2>
 */
function Accent({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontWeight: 'var(--fw-regular)',
      color: 'var(--text-accent)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { SectionHeading, Accent });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/core/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Stat — a big Bricolage display figure over a muted label. Used in the
 * hero metrics row and anywhere a number deserves weight. `accent` paints
 * the figure with the section accent.
 */
function Stat({
  value,
  label,
  accent = false,
  size = 'md',
  style,
  ...rest
}) {
  const sizes = {
    sm: 22,
    md: 38,
    lg: 52
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    className: "ar-stat",
    style: {
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: sizes[size],
      fontWeight: 'var(--fw-bold)',
      letterSpacing: '-0.04em',
      lineHeight: 1,
      color: accent ? 'var(--text-accent)' : 'var(--text-headline)'
    }
  }, value), label && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: size === 'sm' ? 10 : 12,
      color: 'var(--text-muted)',
      marginTop: 8,
      maxWidth: 140,
      lineHeight: 1.3
    }
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stat.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Tag — a mono pill used for tech stack, categories and filters.
 * `active` fills it with the inverted control color (vellum/ink chip).
 */
function Tag({
  children,
  active = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `ar-tag${active ? ' is-active' : ''}`,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.02em',
      padding: '6px 12px',
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--border-strong)',
      background: active ? 'var(--control-bg)' : 'transparent',
      color: active ? 'var(--control-fg)' : 'var(--text-body)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/core/ServiceCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ServiceCard — a numbered offering card. Large index figure, title, short
 * promise, body, and a row of stack Tags. Sits on a raised surface with a
 * hairline border; the index and a hover lift use the section accent.
 */
function ServiceCard({
  index,
  title,
  promise,
  body,
  tools = [],
  metric,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: "ar-service-card",
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: 'relative',
      padding: 28,
      borderRadius: 'var(--radius-lg)',
      background: 'var(--surface-raised)',
      border: `1px solid ${hover ? 'var(--accent)' : 'var(--border-default)'}`,
      boxShadow: hover ? 'var(--shadow-lift)' : 'var(--shadow-soft)',
      transition: 'border-color .2s ease, box-shadow .2s ease, transform .2s ease',
      transform: hover ? 'translateY(-3px)' : 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between'
    }
  }, index != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 40,
      fontWeight: 'var(--fw-bold)',
      letterSpacing: '-0.04em',
      lineHeight: 1,
      color: 'var(--text-accent)'
    }
  }, index), metric && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-mono-sm)',
      letterSpacing: 'var(--tracking-mono-sm)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      textAlign: 'right',
      maxWidth: 120,
      lineHeight: 1.4
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--text-warm)',
      fontWeight: 'var(--fw-medium)'
    }
  }, metric.value), /*#__PURE__*/React.createElement("br", null), metric.label)), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '20px 0 0',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-title)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--tracking-tight)',
      lineHeight: 1.1,
      color: 'var(--text-headline)',
      whiteSpace: 'pre-line'
    }
  }, title), promise && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '12px 0 0',
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontSize: 17,
      color: 'var(--text-warm)',
      lineHeight: 1.3
    }
  }, promise), body && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '14px 0 0',
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-body)',
      lineHeight: 'var(--leading-body)'
    }
  }, body), tools.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6,
      marginTop: 20
    }
  }, tools.map(t => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: t
  }, t))));
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Contacto.jsx
try { (() => {
/* Contacto — dark section, left info + right vellum form card (interactive). */
const NSC = window.AndrSRodrGuezDesignSystem_4ec814;
function Contacto() {
  const {
    SectionHeading,
    Accent,
    Button,
    Input,
    AvailabilityBadge,
    IconButton
  } = NSC;
  const I = window.ARIcons;
  const [sent, setSent] = React.useState(false);
  const channels = [{
    icon: I.mail({
      size: 18,
      style: {
        color: 'var(--ar-azure)'
      }
    }),
    l: 'info@andresrodriguez.tech'
  }, {
    icon: I.phone({
      size: 18,
      style: {
        color: 'var(--ar-azure)'
      }
    }),
    l: '+507 6721 1199'
  }, {
    icon: I.mapPin({
      size: 18,
      style: {
        color: 'var(--ar-azure)'
      }
    }),
    l: 'Ciudad de Panamá, PA'
  }];
  return /*#__PURE__*/React.createElement("section", {
    id: "contact",
    className: "kit-section",
    style: {
      background: 'var(--ar-midnight)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: 'clamp(72px,12vh,100px) clamp(20px,5vw,80px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "contact-grid",
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'clamp(32px,5vw,72px)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "\xA705 \xB7 Contacto",
    deck: "Contame qu\xE9 quer\xE9s resolver \u2014 yo te digo c\xF3mo."
  }, "Hablemos de tu ", /*#__PURE__*/React.createElement(Accent, null, "proyecto"), "."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 36,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, channels.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.l,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 999,
      border: '1px solid var(--ar-steel)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, c.icon), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      color: 'var(--ar-bone)'
    }
  }, c.l)))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 40,
      paddingTop: 22,
      borderTop: '1px solid var(--ar-rule)'
    }
  }, /*#__PURE__*/React.createElement(AvailabilityBadge, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    label: "LinkedIn",
    href: "#"
  }, I.linkedin()), /*#__PURE__*/React.createElement(IconButton, {
    label: "GitHub",
    href: "#"
  }, I.github())))), /*#__PURE__*/React.createElement("div", {
    className: "light",
    style: {
      padding: 'clamp(24px,3vw,36px)',
      borderRadius: 'var(--radius-xl)',
      background: 'var(--ar-vellum)',
      color: 'var(--ar-ink)',
      boxShadow: 'var(--shadow-lift)'
    }
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 360,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 52,
      height: 52,
      borderRadius: 999,
      background: 'var(--ar-azure-deep)',
      color: '#fff',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, I.check({
    size: 26
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 30,
      fontWeight: 700,
      letterSpacing: '-.025em',
      marginTop: 20,
      color: 'var(--ar-ink)'
    }
  }, "Mensaje enviado"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      color: 'rgba(0,0,0,.65)',
      marginTop: 8,
      lineHeight: 1.5
    }
  }, "Gracias \u2014 te respondo en menos de un d\xEDa h\xE1bil."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: () => setSent(false)
  }, "Enviar otro"))) : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 26,
      fontWeight: 700,
      letterSpacing: '-.025em',
      color: 'var(--ar-ink)'
    }
  }, "Env\xEDame un mensaje"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'rgba(0,0,0,.55)',
      marginTop: 6
    }
  }, "Te respondo en menos de un d\xEDa h\xE1bil."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 26,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Tu nombre",
    placeholder: "Andr\xE9s"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Tu correo",
    placeholder: "tu@correo.com"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Asunto",
    placeholder: "Sitio nuevo + dashboard interno"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Mensaje",
    as: "textarea",
    rows: 4,
    placeholder: "Queremos reemplazar nuestro WordPress lento por un sitio r\xE1pido conectado a HubSpot\u2026"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 26,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'rgba(0,0,0,.55)'
    }
  }, "Tu informaci\xF3n no se comparte con nadie."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    type: "submit",
    icon: I.send({
      size: 14,
      style: {
        color: 'var(--control-fg)'
      }
    })
  }, "Enviar mensaje")))))));
}
window.Contacto = Contacto;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Contacto.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Footer.jsx
try { (() => {
/* Footer. */
const NSF = window.AndrSRodrGuezDesignSystem_4ec814;
function Footer() {
  const {
    IconButton
  } = NSF;
  const I = window.ARIcons;
  const cols = [{
    h: 'Navegación',
    l: ['Inicio', 'Servicios', 'Metodología', 'Trayectoria', 'Contacto']
  }, {
    h: 'Servicios',
    l: ['Sitios web', 'Aplicaciones', 'Integraciones', 'Datos en vivo']
  }, {
    h: 'Recursos',
    l: ['Descargar CV', 'LinkedIn', 'GitHub']
  }];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--ar-midnight)',
      borderTop: '1px solid var(--ar-rule)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '60px clamp(20px,5vw,80px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "footer-grid",
    style: {
      display: 'grid',
      gridTemplateColumns: '1.5fr 1fr 1fr 1fr',
      gap: 'clamp(28px,4vw,60px)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ar-wordmark",
    style: {
      fontSize: 38,
      lineHeight: .95
    }
  }, "Andr\xE9s", /*#__PURE__*/React.createElement("br", null), "Rodr\xEDguez", /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, ".")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontSize: 16,
      color: 'var(--ar-cream)',
      marginTop: 10,
      lineHeight: 1.3
    }
  }, "Soluciones digitales alineadas", /*#__PURE__*/React.createElement("br", null), "a procesos clave de negocio."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    label: "LinkedIn",
    href: "#"
  }, I.linkedin()), /*#__PURE__*/React.createElement(IconButton, {
    label: "GitHub",
    href: "#"
  }, I.github()), /*#__PURE__*/React.createElement(IconButton, {
    label: "Email",
    href: "#"
  }, I.mail()))), cols.map(col => /*#__PURE__*/React.createElement("div", {
    key: col.h
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '.22em',
      textTransform: 'uppercase',
      color: 'var(--ar-mist)',
      marginBottom: 16
    }
  }, col.h), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, col.l.map(it => /*#__PURE__*/React.createElement("a", {
    key: it,
    href: "#",
    style: {
      fontSize: 14,
      color: 'var(--ar-bone)'
    },
    onMouseEnter: e => e.currentTarget.style.color = 'var(--ar-vellum)',
    onMouseLeave: e => e.currentTarget.style.color = 'var(--ar-bone)'
  }, it)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 56,
      paddingTop: 24,
      borderTop: '1px solid var(--ar-rule)',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--ar-mist)'
    }
  }, "\xA9 2026 Andr\xE9s Rodr\xEDguez \xB7 Construido en Ciudad de Panam\xE1 ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ar-cream)'
    }
  }, "\u2665")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--ar-mist)',
      letterSpacing: '.18em',
      textTransform: 'uppercase'
    }
  }, "v2.0 \xB7 andresrodriguez.tech"))));
}
window.Footer = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Hero.jsx
try { (() => {
/* Hero — "Hola, soy Andrés Rodríguez." */
const NSH = window.AndrSRodrGuezDesignSystem_4ec814;
function HeroPortrait() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      alignSelf: 'center',
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      borderRadius: 'var(--radius-xl)',
      overflow: 'hidden',
      aspectRatio: '4/5',
      border: '1px solid var(--ar-rule)',
      boxShadow: '0 40px 100px -20px rgba(0,0,0,.9)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 200 250",
    style: {
      width: '100%',
      height: '100%',
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "hp",
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "#1A1A1A"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "#000000"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "hl",
    cx: "0.35",
    cy: "0.3",
    r: "0.5"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "rgba(255,255,255,.5)"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "rgba(255,255,255,0)"
  }))), /*#__PURE__*/React.createElement("rect", {
    width: "200",
    height: "250",
    fill: "url(#hp)"
  }), /*#__PURE__*/React.createElement("rect", {
    width: "200",
    height: "250",
    fill: "url(#hl)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M30 250 Q30 180 65 165 Q75 160 80 155 Q72 145 72 130 Q72 95 100 95 Q128 95 128 130 Q128 145 120 155 Q125 160 135 165 Q170 180 170 250 Z",
    fill: "#0C0C0C",
    stroke: "rgba(255,255,255,.18)",
    strokeWidth: "0.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M82 128 L 92 128 M108 128 L 118 128",
    stroke: "rgba(244,239,230,.4)",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "86",
    cy: "128",
    r: "4",
    fill: "none",
    stroke: "rgba(244,239,230,.3)",
    strokeWidth: "0.8"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "114",
    cy: "128",
    r: "4",
    fill: "none",
    stroke: "rgba(244,239,230,.3)",
    strokeWidth: "0.8"
  })), /*#__PURE__*/React.createElement("span", {
    className: "ar-wordmark",
    style: {
      position: 'absolute',
      bottom: 18,
      left: 22,
      fontSize: 16,
      fontWeight: 600,
      opacity: .9,
      letterSpacing: '-.02em'
    }
  }, "andr\xE9s \xB7 pty 2026")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: -16,
      right: -12
    }
  }, /*#__PURE__*/React.createElement(NSH.AvailabilityBadge, {
    style: {
      background: 'var(--ar-midnight)'
    }
  })));
}
function Hero() {
  const {
    Eyebrow,
    Button,
    IconButton,
    Stat
  } = NSH;
  const I = window.ARIcons;
  const stats = [{
    n: '5+',
    l: 'años de experiencia',
    a: false
  }, {
    n: '30+',
    l: 'proyectos entregados',
    a: true
  }, {
    n: '80%',
    l: 'reducción promedio de tiempo',
    a: false
  }, {
    n: '24h',
    l: 'tiempo de respuesta',
    a: false
  }];
  return /*#__PURE__*/React.createElement("section", {
    id: "inicio",
    className: "kit-section",
    style: {
      position: 'relative',
      overflow: 'hidden',
      minHeight: '100vh'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: -200,
      right: -160,
      width: 700,
      height: 700,
      borderRadius: '50%',
      background: 'radial-gradient(circle, rgba(255,255,255,.16), transparent 60%)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: -200,
      left: -160,
      width: 540,
      height: 540,
      borderRadius: '50%',
      background: 'radial-gradient(circle, rgba(207,207,207,.06), transparent 65%)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "hero-grid",
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: 'clamp(120px,16vh,170px) clamp(20px,5vw,80px) 60px',
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr',
      gap: 'clamp(32px,6vw,80px)',
      position: 'relative',
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Ciudad de Panam\xE1 \xB7 disponible"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '28px 0 0',
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 'clamp(56px, 9vw, 110px)',
      lineHeight: .9,
      letterSpacing: '-.055em',
      color: 'var(--ar-vellum)'
    }
  }, "Hola, soy", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ar-azure)'
    }
  }, "Andr\xE9s"), /*#__PURE__*/React.createElement("br", null), "Rodr\xEDguez."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '26px 0 0',
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontSize: 'clamp(20px,3vw,26px)',
      color: 'var(--ar-cream)',
      lineHeight: 1.2,
      maxWidth: 560
    }
  }, "Soluciones digitales alineadas", /*#__PURE__*/React.createElement("br", null), "a procesos clave de negocio."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '24px 0 0',
      fontSize: 17,
      color: 'var(--ar-bone)',
      maxWidth: 540,
      lineHeight: 1.55
    }
  }, "Desarrollador web full-stack en Panam\xE1 con m\xE1s de 5 a\xF1os construyendo soluciones digitales \u2014 sitios, aplicaciones a medida y plataformas que integran toda la operaci\xF3n de negocio."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      marginTop: 36,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    arrow: true,
    href: "#proyectos"
  }, "Ver mi trabajo"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "lg",
    href: "#contact"
  }, "Descargar CV"), /*#__PURE__*/React.createElement(IconButton, {
    filled: true,
    label: "LinkedIn",
    href: "#"
  }, I.linkedin({
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 60,
      paddingTop: 26,
      borderTop: '1px solid var(--ar-rule)',
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'clamp(28px,4vw,56px)'
    }
  }, stats.map(s => /*#__PURE__*/React.createElement(Stat, {
    key: s.n,
    value: s.n,
    label: s.l,
    accent: s.a
  })))), /*#__PURE__*/React.createElement("div", {
    className: "hide-mobile"
  }, /*#__PURE__*/React.createElement(HeroPortrait, null))), /*#__PURE__*/React.createElement("div", {
    className: "hide-mobile",
    style: {
      position: 'absolute',
      bottom: 24,
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 8,
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--ar-mist)',
      letterSpacing: '.18em'
    }
  }, "SCROLL"), I.scroll({
    style: {
      color: 'var(--ar-azure)'
    }
  })));
}
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Metodologia.jsx
try { (() => {
/* Metodología — the .warm section. Horizontal 4-phase timeline. */
const NSM = window.AndrSRodrGuezDesignSystem_4ec814;
const PHASES = [{
  n: '01',
  name: 'Discovery',
  dur: '1 semana',
  gives: 'Documento + arquitectura técnica',
  detail: 'Entendemos el problema, mapeamos los flujos actuales y definimos el alcance del MVP. Sin esto, lo demás es adivinar.'
}, {
  n: '02',
  name: 'Diseño',
  dur: '1 semana',
  gives: 'Prototipo navegable',
  detail: 'Wireframes y UI en Figma. Tú navegás y aprobás antes de escribir una línea de código.'
}, {
  n: '03',
  name: 'Desarrollo',
  dur: '2 – 3 semanas',
  gives: 'MVP funcional + ambiente staging',
  detail: 'Sprints semanales. Cada viernes te muestro lo construido en una URL que podés probar.'
}, {
  n: '04',
  name: 'Launch',
  dur: '1 semana',
  gives: 'Producción + monitoreo + soporte',
  detail: 'Deploy, configuración de monitoreo, documentación de operación y dos semanas de soporte incluido.'
}];
function Metodologia() {
  const {
    SectionHeading,
    Accent,
    Button
  } = NSM;
  return /*#__PURE__*/React.createElement("section", {
    id: "metodologia",
    className: "warm kit-section",
    style: {
      background: 'var(--ar-paper)',
      color: 'var(--ar-umber)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: -150,
      left: '30%',
      width: 600,
      height: 600,
      borderRadius: '50%',
      background: 'radial-gradient(circle, rgba(0,0,0,.10), transparent 65%)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: 'clamp(72px,12vh,100px) clamp(20px,5vw,80px)',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 60,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "\xA703 \xB7 Metodolog\xEDa",
    style: {
      maxWidth: 760
    }
  }, "De idea a producci\xF3n", /*#__PURE__*/React.createElement("br", null), "en ", /*#__PURE__*/React.createElement(Accent, null, "cuatro"), " fases."), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 340,
      paddingBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontSize: 22,
      color: 'var(--ar-rust)',
      lineHeight: 1.3
    }
  }, "Cinco semanas. Sin caja negra."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'rgba(10,10,10,.72)',
      marginTop: 10,
      lineHeight: 1.6
    }
  }, "Te muestro c\xF3digo en cada entrega \u2014 no esper\xE1s semanas para ver progreso real."))), /*#__PURE__*/React.createElement("div", {
    className: "phase-wrap",
    style: {
      position: 'relative',
      marginTop: 72
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "phase-spine",
    style: {
      position: 'absolute',
      top: 26,
      left: 28,
      right: 28,
      height: 2,
      background: 'linear-gradient(90deg, var(--ar-rust), rgba(0,0,0,.4), rgba(10,10,10,.15))'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "phase-grid",
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 32
    }
  }, PHASES.map((ph, i) => {
    const last = i === PHASES.length - 1;
    return /*#__PURE__*/React.createElement("div", {
      key: ph.n,
      style: {
        position: 'relative',
        paddingTop: 60
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        top: 16,
        left: 0,
        width: 22,
        height: 22,
        borderRadius: 11,
        background: i === 0 ? 'var(--ar-rust)' : last ? 'rgba(10,10,10,.15)' : 'var(--ar-paper)',
        border: `2px solid ${last ? 'rgba(10,10,10,.25)' : 'var(--ar-rust)'}`,
        boxShadow: i === 0 ? '0 0 0 5px rgba(0,0,0,.15)' : 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, i === 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 6,
        height: 6,
        borderRadius: 3,
        background: '#fff'
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        color: 'var(--ar-rust)',
        letterSpacing: '.18em',
        textTransform: 'uppercase',
        fontWeight: 600
      }
    }, "Fase ", ph.n), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 30,
        color: 'var(--ar-umber)',
        fontWeight: 700,
        letterSpacing: '-.025em',
        marginTop: 6,
        lineHeight: 1
      }
    }, ph.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        color: 'rgba(10,10,10,.6)',
        marginTop: 4
      }
    }, "\xB7 ", ph.dur), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 18,
        paddingTop: 14,
        borderTop: '1px dashed rgba(10,10,10,.2)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 9,
        color: 'rgba(10,10,10,.55)',
        letterSpacing: '.18em',
        textTransform: 'uppercase',
        marginBottom: 6
      }
    }, "Entregable"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        color: 'var(--ar-umber)',
        fontWeight: 500,
        lineHeight: 1.35
      }
    }, ph.gives), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'rgba(10,10,10,.7)',
        marginTop: 10,
        lineHeight: 1.55
      }
    }, ph.detail)));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 56,
      paddingTop: 32,
      borderTop: '1px solid rgba(10,10,10,.12)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 40,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontSize: 24,
      color: 'var(--ar-umber)',
      lineHeight: 1.3
    }
  }, "Cada fase tiene un entregable concreto que aprob\xE1s antes de pasar al siguiente."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'rgba(10,10,10,.7)',
      marginTop: 10,
      lineHeight: 1.55
    }
  }, "Si no funciona, ajustamos. No avanzamos hasta que est\xE1s de acuerdo. Sin sorpresas. Sin reuniones de \"qu\xE9 pas\xF3\".")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    arrow: true,
    href: "#contact"
  }, "Reservar un Discovery"))));
}
window.Metodologia = Metodologia;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Metodologia.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Navbar.jsx
try { (() => {
/* Navbar — edge-to-edge bar that materializes as you leave the hero.
   Driven by a single 0..1 scroll progress `p` (from app.jsx). */
const NS = window.AndrSRodrGuezDesignSystem_4ec814;
const NAV_LINKS = [{
  href: '#inicio',
  label: 'Inicio'
}, {
  href: '#proyectos',
  label: 'Servicios'
}, {
  href: '#metodologia',
  label: 'Metodología'
}, {
  href: '#sobre-mi',
  label: 'Trayectoria'
}, {
  href: '#contact',
  label: 'Contacto'
}];
const MOBILE_LINKS = [{
  href: '#inicio',
  n: '01',
  label: 'Inicio'
}, {
  href: '#proyectos',
  n: '02',
  label: 'Servicios'
}, {
  href: '#metodologia',
  n: '03',
  label: 'Metodología'
}, {
  href: '#sobre-mi',
  n: '04',
  label: 'Trayectoria'
}, {
  href: '#contact',
  n: '05',
  label: 'Contacto'
}];
const lerp = (a, b, p) => a + (b - a) * p;
const easeInOut = p => p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
function Navbar({
  progress,
  active
}) {
  const {
    IconButton,
    Button
  } = NS;
  const I = window.ARIcons;
  const [open, setOpen] = React.useState(false);
  const p = easeInOut(progress);
  const padY = lerp(26, 14, p);
  const bgA = lerp(0, 0.92, p);
  const blur = lerp(0, 14, p);
  const borderA = lerp(0, 0.1, p);
  const shadowA = Math.max(0, (p - 0.5) * 1.4);
  const logoSize = lerp(26, 20, p);
  const linkGap = lerp(44, 32, p);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("nav", {
    className: "kit-navbar",
    style: {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 50,
      display: 'flex',
      alignItems: 'center',
      padding: `${padY}px clamp(20px, 5vw, 64px)`,
      background: `rgba(0,0,0,${bgA})`,
      backdropFilter: `blur(${blur}px)`,
      WebkitBackdropFilter: `blur(${blur}px)`,
      borderBottom: `1px solid rgba(244,239,230,${borderA})`,
      boxShadow: shadowA > 0 ? `0 8px 24px -8px rgba(0,0,0,${Math.min(0.6, shadowA * 0.6)})` : 'none',
      transition: 'padding .1s linear'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#inicio",
    className: "ar-wordmark",
    style: {
      fontSize: logoSize
    },
    "aria-label": "Andr\xE9s Rodr\xEDguez \u2014 inicio"
  }, "ar", /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, ".")), /*#__PURE__*/React.createElement("div", {
    className: "hide-mobile",
    style: {
      flex: 1,
      display: 'flex',
      justifyContent: 'center',
      gap: linkGap
    }
  }, NAV_LINKS.map((n, i) => {
    const on = active === n.href;
    return /*#__PURE__*/React.createElement("a", {
      key: n.href,
      href: n.href,
      style: {
        position: 'relative',
        padding: '4px 0',
        fontSize: 14,
        fontWeight: on ? 500 : 400,
        color: on ? 'var(--ar-vellum)' : 'var(--ar-mist)',
        transition: 'color .2s ease'
      },
      onMouseEnter: e => {
        if (!on) e.currentTarget.style.color = 'var(--ar-vellum)';
      },
      onMouseLeave: e => {
        if (!on) e.currentTarget.style.color = 'var(--ar-mist)';
      }
    }, n.label, on && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        height: 1,
        background: 'var(--ar-azure)'
      }
    }));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "hide-mobile"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    href: "#contact"
  }, "Descargar CV")), /*#__PURE__*/React.createElement("span", {
    className: "only-mobile"
  }, /*#__PURE__*/React.createElement(IconButton, {
    label: "Abrir men\xFA",
    onClick: () => setOpen(true)
  }, I.menu())))), /*#__PURE__*/React.createElement("div", {
    className: "only-mobile",
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 60,
      background: 'var(--ar-ink)',
      opacity: open ? 1 : 0,
      pointerEvents: open ? 'auto' : 'none',
      transition: 'opacity .3s ease'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '26px clamp(20px,5vw,64px)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ar-wordmark",
    style: {
      fontSize: 22
    }
  }, "ar", /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, ".")), /*#__PURE__*/React.createElement(IconButton, {
    label: "Cerrar men\xFA",
    filled: true,
    onClick: () => setOpen(false)
  }, I.x())), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 28px 32px',
      display: 'flex',
      flexDirection: 'column',
      height: 'calc(100% - 92px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, MOBILE_LINKS.map((item, i) => /*#__PURE__*/React.createElement("a", {
    key: item.href,
    href: item.href,
    onClick: () => setOpen(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '20px 0',
      borderBottom: '1px solid var(--ar-rule)',
      transform: open ? 'translateX(0)' : 'translateX(-16px)',
      opacity: open ? 1 : 0,
      transition: `transform .35s ease ${i * 40}ms, opacity .35s ease ${i * 40}ms`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'baseline',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--ar-mist)'
    }
  }, item.n), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 36,
      letterSpacing: '-.03em',
      color: 'var(--ar-bone)'
    }
  }, item.label)), I.arrow({
    size: 20,
    style: {
      color: 'var(--ar-mist)'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      alignItems: 'stretch'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    href: "#contact",
    onClick: () => setOpen(false)
  }, "Descargar CV"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(NS.AvailabilityBadge, null))))));
}
window.Navbar = Navbar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Navbar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Servicios.jsx
try { (() => {
/* Servicios — the .light section. 4 numbered offerings + dashboard mockup. */
const NSS = window.AndrSRodrGuezDesignSystem_4ec814;
const SERVICES = [{
  n: '01',
  title: 'Sitios que\ncaptan',
  promise: 'Tu mejor vendedor, online 24/7.',
  body: 'Landing pages y sitios corporativos rápidos, optimizados para SEO y pensados para convertir visitas en conversaciones reales — no en bounce.',
  tools: ['Next.js', 'Vercel', 'Tailwind', 'SEO'],
  metric: {
    value: '24/7',
    label: 'siempre disponible'
  }
}, {
  n: '02',
  title: 'Aplicaciones\nweb a medida',
  promise: 'Cuando Excel y los plugins ya no alcanzan.',
  body: 'Software hecho para tu flujo real — no plantillas. Reemplaza hojas de cálculo compartidas, CRMs genéricos y procesos manuales con una herramienta que tu equipo sí quiere abrir.',
  tools: ['React', 'Django', 'PostgreSQL', 'TS'],
  metric: {
    value: '100%',
    label: 'hecho a tu medida'
  }
}, {
  n: '03',
  title: 'Integraciones\nque conectan',
  promise: 'Una sola fuente de verdad.',
  body: 'Tu sitio enlazado con CRM, cobros, correo, automatizaciones y datos — sin copiar/pegar entre cinco pestañas. Lo que pasa en uno, pasa en todos.',
  tools: ['HubSpot', 'n8n', 'APIs REST', 'Stripe'],
  metric: {
    value: '5→1',
    label: 'herramientas unificadas'
  }
}, {
  n: '04',
  title: 'Datos\nen vivo',
  promise: 'Decide con información, no con intuición.',
  body: 'Dashboards que muestran el pulso real del negocio: ventas, usuarios, KPIs operativos. Conectados directo a tu base de datos — sin reportes de viernes.',
  tools: ['Power BI', 'Metabase', 'SQL', 'BI'],
  metric: {
    value: 'live',
    label: 'tiempo real'
  }
}];
function DashboardMock() {
  const rows = [{
    code: '#1284',
    name: 'J. Rivera',
    status: 'revisión',
    ok: false
  }, {
    code: '#1283',
    name: 'M. Castro',
    status: 'aprobada',
    ok: true
  }, {
    code: '#1282',
    name: 'A. González',
    status: 'aprobada',
    ok: true
  }];
  const stats = [{
    l: 'Activas',
    v: '124',
    d: '+12'
  }, {
    l: 'Aprobadas',
    v: '89',
    d: '72%'
  }, {
    l: 'Tiempo',
    v: '1.4d',
    d: '−23%'
  }];
  const bars = [35, 50, 42, 65, 58, 72, 80, 70, 88, 82, 92, 100];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#FFFFFF',
      border: '1px solid rgba(0,0,0,.10)',
      borderRadius: 14,
      boxShadow: 'var(--shadow-card-light)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 34,
      padding: '0 14px',
      borderBottom: '1px solid rgba(0,0,0,.08)',
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      background: '#EDEDEB'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: 5,
      background: '#3C3C3C'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: 5,
      background: '#585858'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: 5,
      background: '#767676'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      margin: '0 40px 0 16px',
      padding: '3px 10px',
      background: '#fff',
      borderRadius: 5,
      border: '1px solid rgba(0,0,0,.08)',
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'rgba(0,0,0,.55)'
    }
  }, "app.tuempresa.com / operaciones")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'rgba(0,0,0,.5)',
      letterSpacing: '.1em',
      textTransform: 'uppercase'
    }
  }, "Operaciones \xB7 Q1"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 20,
      color: '#000000',
      fontWeight: 700,
      marginTop: 3,
      letterSpacing: '-.025em'
    }
  }, "Solicitudes")), /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '6px 14px',
      background: '#111111',
      color: '#fff',
      borderRadius: 6,
      fontSize: 11,
      fontWeight: 600
    }
  }, "+ Nueva")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 8,
      marginBottom: 12
    }
  }, stats.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.l,
    style: {
      padding: '9px 11px',
      background: '#F8F6F1',
      border: '1px solid rgba(0,0,0,.06)',
      borderRadius: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 8,
      color: 'rgba(0,0,0,.5)',
      letterSpacing: '.08em',
      textTransform: 'uppercase'
    }
  }, s.l), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 19,
      color: '#000000',
      fontWeight: 700,
      letterSpacing: '-.03em',
      marginTop: 2
    }
  }, s.v), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: '#111111',
      marginTop: 1
    }
  }, s.d)))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 11,
      background: '#F8F6F1',
      border: '1px solid rgba(0,0,0,.06)',
      borderRadius: 8,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'rgba(0,0,0,.5)',
      marginBottom: 8,
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", null, "VOLUMEN \xB7 12 SEM"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#111111'
    }
  }, "+34%")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 4,
      height: 56
    }
  }, bars.map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: `${h}%`,
      background: i >= 10 ? '#111111' : i >= 7 ? 'rgba(17,17,17,.5)' : 'rgba(17,17,17,.18)',
      borderRadius: '2px 2px 0 0'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, rows.map(r => /*#__PURE__*/React.createElement("div", {
    key: r.code,
    style: {
      padding: '7px 9px',
      background: '#fff',
      border: '1px solid rgba(0,0,0,.06)',
      borderRadius: 6,
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      fontSize: 11
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      color: 'rgba(0,0,0,.5)',
      fontSize: 9
    }
  }, r.code), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      color: '#000000'
    }
  }, "Solicitud \xB7 ", r.name), /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '2px 8px',
      background: r.ok ? 'rgba(0,0,0,.14)' : 'rgba(207,207,207,.4)',
      color: r.ok ? '#111111' : '#555555',
      borderRadius: 4,
      fontSize: 9
    }
  }, r.status))))));
}
function Servicios() {
  const {
    SectionHeading,
    Accent,
    Button,
    Tag
  } = NSS;
  const I = window.ARIcons;
  return /*#__PURE__*/React.createElement("section", {
    id: "proyectos",
    className: "light kit-section",
    style: {
      background: 'var(--ar-mist-bg)',
      color: 'var(--ar-ink)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'radial-gradient(ellipse 80% 60% at 80% 0%, rgba(255,255,255,.16), transparent 65%)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: 'clamp(72px,12vh,100px) clamp(20px,5vw,80px)',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "\xA702 \xB7 Servicios",
    deck: "Software que se acopla a tu flujo \u2014 no al rev\xE9s."
  }, "Lo que ", /*#__PURE__*/React.createElement(Accent, null, "construyo"), "."), /*#__PURE__*/React.createElement("div", {
    className: "svc-grid",
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2,1fr) 1.2fr',
      gap: 20,
      marginTop: 56,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(NSS.ServiceCard, mapSvc(SERVICES[0])), /*#__PURE__*/React.createElement(NSS.ServiceCard, mapSvc(SERVICES[1])), /*#__PURE__*/React.createElement("div", {
    style: {
      gridRow: 'span 2',
      alignSelf: 'stretch',
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '.18em',
      textTransform: 'uppercase',
      color: 'rgba(0,0,0,.5)'
    }
  }, "\u2014 fragmento de un CRM hecho a medida"), /*#__PURE__*/React.createElement(DashboardMock, null)), /*#__PURE__*/React.createElement(NSS.ServiceCard, mapSvc(SERVICES[2])), /*#__PURE__*/React.createElement(NSS.ServiceCard, mapSvc(SERVICES[3]))), /*#__PURE__*/React.createElement("div", {
    className: "svc-footer",
    style: {
      marginTop: 56,
      paddingTop: 28,
      borderTop: '1px solid rgba(0,0,0,.10)',
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 32,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'rgba(0,0,0,.55)',
      letterSpacing: '.22em',
      textTransform: 'uppercase',
      marginBottom: 12
    }
  }, "Stack principal"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap',
      maxWidth: 720
    }
  }, ['Next.js', 'React', 'TypeScript', 'Django', 'Node.js', 'PostgreSQL', 'Tailwind', 'Vercel'].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t)))), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    arrow: true,
    href: "#contact"
  }, "Hablemos del proyecto"))));
}
function mapSvc(s) {
  return {
    index: s.n,
    title: s.title,
    promise: s.promise,
    body: s.body,
    tools: s.tools,
    metric: s.metric
  };
}
window.Servicios = Servicios;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Servicios.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Trayectoria.jsx
try { (() => {
/* Trayectoria — dark vertical timeline. */
const NST = window.AndrSRodrGuezDesignSystem_4ec814;
const TIMELINE = [{
  year: '2025',
  span: 'Actualidad',
  title: 'Desarrollo web moderno · IA',
  org: 'Financiera Pacífico',
  role: 'Líder técnico · CRM personalizado',
  body: 'Lideré el diseño y desarrollo de un CRM a medida que reemplazó HubSpot, alineado a los flujos reales del equipo. Reducción del "time to yes" en aprobación de préstamos.',
  tags: ['Django', 'React', 'PostgreSQL', 'AI'],
  highlight: false
}, {
  year: '2022 – 2025',
  span: '3 años',
  title: 'RPA · Datos · CRM en banca y seguros',
  org: 'Corporación Pacífico · ITICO RE',
  role: 'Desarrollador RPA · Analista de datos',
  body: 'Lideré el plan piloto de una célula RPA y el diseño de un framework interno. Participación en proyecto HubSpot, chatbots de captura y tableros Power BI.',
  tags: ['UiPath', 'HubSpot', 'Power BI', 'App Script'],
  highlight: false
}, {
  year: '2020',
  span: 'Punto de inflexión',
  title: 'COVID-19 · Transición a RPA',
  org: 'Applus Norcontrol',
  role: 'Desarrollador RPA',
  body: 'La pandemia generó acumulación masiva de órdenes pendientes. Levanté infraestructura digital y procesos automáticos que mantuvieron las operaciones críticas durante el confinamiento.',
  tags: ['UiPath', 'Crisis ops', 'Digital ramp-up'],
  highlight: true
}, {
  year: '2018 – 2022',
  span: 'Inicio',
  title: 'Análisis de datos · BI',
  org: 'Applus Norcontrol',
  role: 'Analista de datos',
  body: 'Diseño de paneles Power BI, macros VBA y digitalización de formularios. Base sólida en análisis que después permitió evolucionar al desarrollo RPA.',
  tags: ['Power BI', 'Excel/VBA', 'Kizeo Forms'],
  highlight: false
}];
function Trayectoria() {
  const {
    SectionHeading,
    Accent,
    Tag
  } = NST;
  return /*#__PURE__*/React.createElement("section", {
    id: "sobre-mi",
    className: "kit-section",
    style: {
      background: 'var(--ar-ink)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: 'clamp(72px,12vh,100px) clamp(20px,5vw,80px)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "\xA704 \xB7 Trayectoria",
    deck: "De analista de datos a desarrollador RPA a l\xEDder t\xE9cnico."
  }, "Siete a\xF1os, ", /*#__PURE__*/React.createElement(Accent, {
    style: {
      color: 'var(--ar-cream)'
    }
  }, "una"), " l\xEDnea."), /*#__PURE__*/React.createElement("div", {
    className: "tl",
    style: {
      position: 'relative',
      paddingLeft: 60,
      marginTop: 56
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 14,
      top: 8,
      bottom: 8,
      width: 1,
      background: 'linear-gradient(180deg, var(--ar-azure), var(--ar-steel), transparent)'
    }
  }), TIMELINE.map((it, i) => {
    const last = i === TIMELINE.length - 1;
    return /*#__PURE__*/React.createElement("div", {
      key: it.year,
      style: {
        position: 'relative',
        paddingBottom: last ? 0 : 56
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: -53,
        top: 14,
        width: 30,
        height: 30,
        borderRadius: 15,
        background: it.highlight ? 'var(--ar-azure)' : 'var(--ar-ink)',
        border: it.highlight ? '4px solid rgba(255,255,255,.2)' : '2px solid var(--ar-steel)',
        boxShadow: it.highlight ? '0 0 0 6px rgba(255,255,255,.1)' : 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, it.highlight && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 8,
        height: 8,
        background: 'var(--ar-vellum)',
        borderRadius: 4
      }
    })), /*#__PURE__*/React.createElement("div", {
      className: "tl-row",
      style: {
        display: 'grid',
        gridTemplateColumns: '180px 1fr',
        gap: 40,
        alignItems: 'flex-start'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 32,
        color: it.highlight ? 'var(--ar-azure)' : 'var(--ar-vellum)',
        fontWeight: 700,
        lineHeight: 1,
        letterSpacing: '-.04em'
      }
    }, it.year), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 10,
        color: 'var(--ar-mist)',
        letterSpacing: '.14em',
        textTransform: 'uppercase',
        marginTop: 6
      }
    }, it.span)), /*#__PURE__*/React.createElement("div", {
      style: it.highlight ? {
        padding: 28,
        borderRadius: 'var(--radius-lg)',
        background: 'linear-gradient(180deg, rgba(255,255,255,.08), rgba(255,255,255,.02))',
        border: '1px solid rgba(255,255,255,.3)',
        position: 'relative'
      } : {}
    }, it.highlight && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -10,
        left: 24,
        padding: '4px 10px',
        background: 'var(--ar-azure)',
        color: 'var(--ar-ink)',
        fontFamily: 'var(--font-mono)',
        fontSize: 10,
        letterSpacing: '.18em',
        fontWeight: 600,
        borderRadius: 999
      }
    }, "COVID-19 \xB7 INFLEXI\xD3N"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 26,
        color: 'var(--ar-vellum)',
        fontWeight: 700,
        lineHeight: 1.1,
        letterSpacing: '-.025em'
      }
    }, it.title), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        color: 'var(--ar-azure)',
        marginTop: 6
      }
    }, it.org), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        color: 'var(--ar-mist)',
        marginTop: 4
      }
    }, it.role), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        color: 'var(--ar-bone)',
        marginTop: 14,
        lineHeight: 1.6,
        maxWidth: 640
      }
    }, it.body), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 6,
        marginTop: 16,
        flexWrap: 'wrap'
      }
    }, it.tags.map(t => /*#__PURE__*/React.createElement(Tag, {
      key: t
    }, t))))));
  }))));
}
window.Trayectoria = Trayectoria;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Trayectoria.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/app.jsx
try { (() => {
/* Root app — scroll progress (navbar morph) + active-section tracking. */
const NSA = window.AndrSRodrGuezDesignSystem_4ec814;
function App() {
  const [progress, setProgress] = React.useState(0);
  const [active, setActive] = React.useState('#inicio');
  React.useEffect(() => {
    let raf = 0;
    const compute = () => {
      const t = window.innerHeight - 80;
      setProgress(Math.max(0, Math.min(1, window.scrollY / t)));
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(compute);
    };
    compute();
    window.addEventListener('scroll', onScroll, {
      passive: true
    });
    return () => {
      window.removeEventListener('scroll', onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);
  React.useEffect(() => {
    const ids = ['#inicio', '#proyectos', '#metodologia', '#sobre-mi', '#contact'];
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) setActive('#' + e.target.id);
      });
    }, {
      rootMargin: '-45% 0px -50% 0px'
    });
    ids.forEach(id => {
      const el = document.querySelector(id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Navbar, {
    progress: progress,
    active: active
  }), /*#__PURE__*/React.createElement(Hero, null), /*#__PURE__*/React.createElement(Servicios, null), /*#__PURE__*/React.createElement(Metodologia, null), /*#__PURE__*/React.createElement(Trayectoria, null), /*#__PURE__*/React.createElement(Contacto, null), /*#__PURE__*/React.createElement(Footer, null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/icons.js
try { (() => {
/* Shared icon set — Lucide-style 1.5 stroke, matching the production site
   (which uses lucide-react). Exposed as window.ARIcons. */
(function () {
  const React = window.React;
  const s = (paths, props = {}) => React.createElement('svg', {
    width: props.size || 18,
    height: props.size || 18,
    viewBox: '0 0 24 24',
    fill: props.fill || 'none',
    stroke: props.fill ? 'none' : 'currentColor',
    strokeWidth: props.sw || 1.5,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    'aria-hidden': true,
    ...props
  }, paths.map((d, i) => typeof d === 'string' ? React.createElement('path', {
    key: i,
    d
  }) : React.createElement(d.t, {
    key: i,
    ...d.a
  })));
  window.ARIcons = {
    arrow: p => s(['M5 12h14M13 6l6 6-6 6'], {
      sw: 2,
      ...p
    }),
    menu: p => s(['M4 7h16M4 12h16M4 17h16'], p),
    x: p => s(['M6 6l12 12M6 18L18 6'], {
      sw: 2,
      ...p
    }),
    send: p => s(['M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z'], {
      sw: 2,
      ...p
    }),
    code: p => s(['M16 18l6-6-6-6', 'M8 6l-6 6 6 6'], {
      sw: 2,
      ...p
    }),
    link: p => s(['M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.71 1.71', 'M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71'], p),
    chart: p => s(['M4 19V5', 'M4 19h16', 'M8 15v-4', 'M12 15V7', 'M16 15v-6'], p),
    globe: p => s(['M3 6h18v12H3z', 'M3 9h18'], p),
    check: p => s(['M20 6 9 17l-5-5'], {
      sw: 2,
      ...p
    }),
    scroll: p => s(['M7 3v12M3 11l4 4 4-4'], p),
    mapPin: p => s(['M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0 1 18 0z', {
      t: 'circle',
      a: {
        cx: 12,
        cy: 10,
        r: 3
      }
    }], p),
    mail: p => s(['M4 4h16v16H4z', 'm4 6 8 6 8-6'], p),
    phone: p => s(['M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z'], p),
    linkedin: p => React.createElement('svg', {
      width: p && p.size || 18,
      height: p && p.size || 18,
      viewBox: '0 0 24 24',
      fill: 'currentColor',
      'aria-hidden': true
    }, React.createElement('path', {
      d: 'M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z'
    })),
    github: p => React.createElement('svg', {
      width: p && p.size || 18,
      height: p && p.size || 18,
      viewBox: '0 0 24 24',
      fill: 'currentColor',
      'aria-hidden': true
    }, React.createElement('path', {
      d: 'M12 2A10 10 0 0 0 2 12c0 4.42 2.87 8.17 6.84 9.5.5.08.66-.23.66-.5v-1.69c-2.77.6-3.36-1.34-3.36-1.34-.46-1.16-1.11-1.47-1.11-1.47-.91-.62.07-.6.07-.6 1 .07 1.53 1.03 1.53 1.03.87 1.52 2.34 1.07 2.91.83.09-.65.35-1.09.63-1.34-2.22-.25-4.55-1.11-4.55-4.92 0-1.11.38-2 1.03-2.71-.1-.25-.45-1.29.1-2.64 0 0 .84-.27 2.75 1.02.79-.22 1.65-.33 2.5-.33.85 0 1.71.11 2.5.33 1.91-1.29 2.75-1.02 2.75-1.02.55 1.35.2 2.39.1 2.64.65.71 1.03 1.6 1.03 2.71 0 3.82-2.34 4.66-4.57 4.91.36.31.69.92.69 1.85V21c0 .27.16.59.67.5C19.14 20.16 22 16.42 22 12A10 10 0 0 0 12 2z'
    }))
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/icons.js", error: String((e && e.message) || e) }); }

__ds_ns.AvailabilityBadge = __ds_scope.AvailabilityBadge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.Accent = __ds_scope.Accent;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Tag = __ds_scope.Tag;

})();
