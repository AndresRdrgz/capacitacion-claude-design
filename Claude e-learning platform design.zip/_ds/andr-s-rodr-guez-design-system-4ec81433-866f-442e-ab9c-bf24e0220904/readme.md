# Andrés Rodríguez — Design System

The brand and interface system for **Andrés Rodríguez**, a full-stack web
developer based in Ciudad de Panamá (`andresrodriguez.tech`). It is the
production **monochrome black** system: a pure-black, greyscale editorial
portfolio brand in Spanish (es-PA) that pairs a grotesk display face with an
italic serif accent.

> One person, one product: a personal portfolio / lead-gen site. Everything
> here serves that voice — confident, technical, business-outcome-driven.

---

## Sources

This system was distilled from a handed-off codebase (read-only, mounted as
`Andres Rodriguez/`):

- **`handoff/app/`** — production Next.js drop-in (the source of truth for
  tokens): `globals.css` (Tailwind `@theme` brand tokens, `:root` + `.light`
  scopes), `layout.tsx` (`next/font/google` wiring), `components/Navbar.tsx`,
  `NavbarMobileMenu.tsx`, `hooks/useScrollProgress.ts`.
- **`cards-*.jsx` / `tokens.jsx`** — an exploration deck for two directions
  ("Atelier" + "Signal") that converged on **Direction C** (the hybrid shipped
  here): full page sections (Hero, Servicios, Metodología, Trayectoria,
  Contacto, Footer), component specimens, and the copy used throughout.
- **`uploads/pasted-…png`** — a Vercel screenshot used only as loose layout
  inspiration (not part of the brand).

Live site: `https://www.andresrodriguez.tech` · Contact in the brand:
`info@andresrodriguez.tech` · `+507 6721 1199`.

---

## Index / manifest

**Root**
- `styles.css` — the single entry point consumers link (`@import` manifest only).
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`,
  `radii.css`, `base.css`.
- `SKILL.md` — Agent-Skills-compatible usage guide.

**Components** (`components/core/`, namespace `window.AndrSRodrGuezDesignSystem_4ec814`)
`Button` · `IconButton` · `Tag` · `Input` · `Eyebrow` · `SectionHeading` +
`Accent` · `Stat` · `AvailabilityBadge` · `ServiceCard` · `Card`.
Each ships `.jsx` + `.d.ts` + `.prompt.md`; `core.card.html` is the specimen.

**Foundation cards** (`guidelines/`) — Colors (ramp, accents, themes), Type
(display, serif, body, mono, scale), Spacing (scale, radii, elevation), Brand
(wordmark, section opener, motifs).

**UI kit** (`ui_kits/portfolio/`) — full interactive recreation of the
portfolio site. See its `README.md`.

---

## Content fundamentals

**Language.** Spanish, Panama register (es-PA). Mixes neutral *tú* with regional
*vos* conjugations in body copy — e.g. <q>navegás</q>, <q>aprobás</q>,
<q>esperás</q>, <q>podés probar</q>. Headlines and labels stay neutral; the
*vos* warmth appears in explanatory prose.

**Person & address.** First person singular ("diseño y construyo", "te muestro",
"te respondo"). Speaks directly to a *you* who runs a business and is frustrated
with their current tools. The reader is a decision-maker, not a developer.

**Tone.** Confident, plain-spoken, anti-fluff. Names the pain bluntly and the
remedy concretely. Examples:
- <q>Cuando Excel y los plugins ya no alcanzan.</q>
- <q>Software que se acopla a tu flujo — no al revés.</q>
- <q>Cinco semanas. Sin caja negra.</q>
- <q>Decide con información, no con intuición.</q>
- <q>sin reportes de viernes</q> · <q>sin reuniones de "qué pasó"</q>

**Devices.**
- **Em-dash asides** carry the sharp clarifier: <q>a medida — no plantillas</q>.
- **Antithesis** ("X, no Y") is the signature rhetorical move:
  <q>A medida, no plantilla</q>, <q>no al revés</q>, <q>no en bounce</q>.
- **Compressed metrics as copy**: `5→1`, `80%`, `24/7`, `time to yes`.
- **Section marks**: every section is numbered `§02 · Servicios` in mono.
- **Lowercase mono labels** for ambient status: `responde < 24h`,
  `andrés · pty 2026`, `scroll`.

**Casing.** Display headlines are sentence case, never all-caps. Mono eyebrows,
metadata and captions are UPPERCASE with wide tracking. The wordmark is
lowercase: `ar.` / `Andrés Rodríguez.`

**Numbers / units.** Spanish decimal-and-thousands conventions; `−23%` uses a
true minus; spans written `2022 – 2025`.

**Emoji.** Effectively none. The only pictographic flourishes are a single
`♥` in the footer credit and the grey status dot. No emoji in product UI.

---

## Visual foundations

**Palette.** Monochrome black-and-white. The spine runs pure black
`ink #000000` → `midnight #0C0C0C` → `slate #161616` → `steel #2C2C2C`
(borders), with text stepping `mist #8A8A8A` (muted) → `bone #C4C4C4` (body) →
`vellum #EDEDEB` (headline). There is no chromatic accent: the primary accent is
pure **white `#FFFFFF`** (the wordmark dot, eyebrow rule, focus ring, and the
one highlighted word per headline — which leans on the italic-serif treatment
more than on contrast), with `grey #CFCFCF` as a quiet secondary (serif decks,
the availability dot). Two alternate section scopes flip every semantic token to
greyscale: **`.light`** (Servicios) on `mist-bg #F2F1EE` with white cards and a
near-black `#111111` accent; **`.warm`** (Metodología) on soft paper-grey
`#E7E6E2` with an `umber #0A0A0A` ink/accent. Use at most these three
greyscale treatments — keep it strictly monochrome, no color.

**Type.** Four families, each with a fixed job:
- **Bricolage Grotesque** (display, 400–800, tracking **−0.05em**) — headlines,
  stat figures, the `ar.` wordmark. Tight, confident, sentence case.
- **Instrument Serif** (regular + *italic*) — the editorial accent: one colored
  word inside a headline, the serif deck under it, and input labels.
- **Geist** (300–700) — all body copy (15px default, 17px lede).
- **Geist Mono** (400–500) — eyebrows, `§` marks, metadata, dashboard data,
  captions. UPPERCASE, tracking 0.18–0.22em.

**Headline lockup.** The recurring rhythm: a 28px accent rule + mono eyebrow,
then a large Bricolage headline with exactly one italic-serif accent word
(<q>a tu <em>medida</em></q>, <q>en <em>cuatro</em> fases</q>), then an italic
serif deck. See `SectionHeading` / `Accent`.

**Spacing & layout.** Shared scale `4 · 8 · 12 · 16 · 24 · 32 · 48 · 64 · 96`.
Content maxes at 1280px; sections breathe at 72–100px vertical, 80px side
gutters (22px mobile). Generous, editorial — lots of negative space.

**Backgrounds.** Flat brand colors, not gradients — except large, very soft
**radial glows** (a faint white bloom ~12–16%) bleeding from a corner to add
depth on black sections. No textures, no patterns, no photographic full-bleeds,
no color washes — the depth is purely tonal.

**Corners & cards.** Radii: inputs 4, chips/panels 8, **cards 16**, media/hero
panels 28, **buttons & badges fully pill (999)**. A resting card = raised surface
+ 1px hairline border (`--border-default`) + soft shadow. Featured cards (e.g.
the COVID inflection item) swap to a white-glow border. Light-section dashboard
mockups use a deep drop shadow (`--shadow-card-light`).

**Elevation.** Three dark shadows — `soft` (resting, with a 1px inset
top-highlight), `lift` (hover/dialog), `glow` (focus/featured, white ring). On
light surfaces, `shadow-card-light` for floating product mockups.

**Borders & rules.** Hairlines everywhere: `rgba(200,208,222,.12)` on dark.
Section dividers, stat rows, timeline entries and footer columns are separated
by 1px rules; dashed rules (`1px dashed`) mark "Entregable" sub-blocks.

**Motion.** Restrained and physical. The hero→nav **morph** interpolates many
properties off one eased scroll value (`easeInOut`) so the bar feels like a
single object consolidating. Hover = color shift or a −3px card lift with a
shadow upgrade; transitions ~0.18–0.2s ease. Mobile menu links stagger in
(40ms steps). An editorial caret blinks in focused inputs. No bounces, no
parallax, no infinite decorative loops.

**Hover / press.** Links: mist → vellum. Primary button: vellum → pure white.
Ghost button: border/text brighten. Cards: lift + accent border. Press states
rely on color, not scale, except the subtle button transform.

**Focus.** White ring — `0 0 0 4px rgba(255,255,255,.30)` on black, the
near-black equivalent on light. Inputs brighten their baseline rule and label to
the accent.

**Transparency / blur.** Used sparingly and purposefully: the navbar backdrop
fades from transparent to `rgba(5,11,26,.92)` with up to 14px blur as you
scroll; floating capsules sit on `surface 60%` translucency. No glassmorphism
elsewhere.

**Imagery vibe.** The hero portrait and product screenshots read cool, low-key
and near-greyscale (the real photo `fotoPerfil.jpg` ships from the site, not the
codebase — placeholders stand in here). Dashboard mockups are clean, light and
data-forward with a near-black accent.

---

## Iconography

- **System:** [Lucide](https://lucide.dev) — the production site uses
  `lucide-react`. Stroke **1.5** (2 for arrows/sends), round caps and joins, on a
  24px grid. `ui_kits/portfolio/icons.js` is a self-contained Lucide-style set
  plus brand glyphs; no icon font is shipped.
- **The arrow `→`** (`M5 12h14M13 6l6 6-6 6`) is the brand's signature glyph —
  on every primary CTA, mobile menu row and "siguiente" affordance.
- **Brand-fill icons:** LinkedIn and GitHub use solid (filled) marks; everything
  else is stroked.
- **Custom stroke set:** Servicios uses a small bespoke set (globe/web, code,
  link, chart) drawn in the same 1.5-stroke language.
- **Emoji:** not used as icons. Unicode is limited to the footer `♥` and `§`
  section marks. Status is shown with a small colored **dot**, not an emoji.
- If you need an icon not in `icons.js`, pull it from Lucide at 1.5 stroke to
  stay consistent.

---

## Caveats

- **Fonts load from the Google Fonts CDN** (`tokens/fonts.css`), matching the
  site's `next/font/google` setup. They are not self-hosted as binaries here, so
  the compiler reports 0 `@font-face`. If you need fully offline/self-hosted
  fonts, drop the `.woff2` files in and swap the `@import` for `@font-face`.
- **Hero portrait & dashboard screenshots are placeholders** — the real
  `fotoPerfil.jpg` and product captures weren't in the handoff. Add them to
  `assets/` and swap them into the UI kit.
